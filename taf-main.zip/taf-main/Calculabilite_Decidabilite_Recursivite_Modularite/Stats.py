def somme (lst): 
    return sum(lst)

def moyenne (lst):
    return sum(lst)/len(lst)
