## Exo 4 
# def inverse(ch):
#     if len(ch) <= 0 :
#         return ch 
#     return ch[-1] + inverse(ch[:-1])

# rep = inverse('abcdefg')
# print(rep)

## Exo 5 : 
# def syracuse(u_n): 
#     print(u_n)

#     if u_n == 1:
#         return 
#     if u_n % 2 == 0 :
#         syracuse(u_n // 2)
#     else:
#         syracuse(3*u_n + 1)

# u1 = syracuse(13)
# print(u1)
